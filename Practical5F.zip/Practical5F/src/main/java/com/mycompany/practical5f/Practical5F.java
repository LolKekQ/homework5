/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practical5f;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author М_З_А
 */
public class Practical5F {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Практика №5, Пашин Александр, РИБО-01-21, вариант 1");
        System.out.println("Введите количество файлов для склейки: ");
        int fN;
        try{
            fN = scan.nextInt();
            String path;
            ArrayList<String> newPath = new ArrayList<>();
            ArrayList<String> pathes = new ArrayList<>();
            for (int i=0; i<fN; i++){
                System.out.println("Введите путь к файлу (не забудьте разделитель): ");
                path = scan.next();
                try{
                    if (i==0){
                        for (String j: path.split("//")){
                            newPath.add(j);
                        }
                        newPath.remove(newPath.size()-1);
                        newPath.add("sumFiles.txt");
                        File file = new File(String.join("//", newPath));
                        pathes.add(String.join("//", newPath));
                        pathes.add(path);
                        Utils.sumFile(pathes.get(0), pathes.get(1));
                    }else{
                        pathes.add(path);
                        Utils.sumFile(pathes.get(0), pathes.get(i+1));
                    }
                }catch(IOException ex){
                    System.out.println("Указанного файла не существует, попробуйте снова");
                    break;
                }
            }
        }catch(InputMismatchException ex){
            System.out.println("Неправильный тип данных, попробуйте ещё раз");
        }
    }
}
